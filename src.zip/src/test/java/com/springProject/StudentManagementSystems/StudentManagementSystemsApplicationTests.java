package com.springProject.StudentManagementSystems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementSystemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
